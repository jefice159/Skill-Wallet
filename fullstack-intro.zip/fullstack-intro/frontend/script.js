const BACKEND_URL = 'http://localhost:5000';

const fetchBtn = document.getElementById('fetchBtn');
const addBtn = document.getElementById('addBtn');
const studentsList = document.getElementById('studentsList');
const loading = document.getElementById('loading');
const error = document.getElementById('error');

// Fetch students from backend
fetchBtn.addEventListener('click', fetchStudents);

// Add new student
addBtn.addEventListener('click', addStudent);

async function fetchStudents() {
    loading.style.display = 'block';
    error.style.display = 'none';
    studentsList.innerHTML = '';

    try {
        const response = await fetch(`${BACKEND_URL}/api/students`);
        
        if (!response.ok) {
            throw new Error('Failed to fetch students');
        }

        const students = await response.json();
        
        loading.style.display = 'none';
        
        if (students.length === 0) {
            studentsList.innerHTML = '<p style="text-align: center; color: #999;">No students found</p>';
            return;
        }

        students.forEach(student => {
            const studentCard = document.createElement('div');
            studentCard.className = 'student-card';
            studentCard.innerHTML = `
                <h4>👤 ${student.name}</h4>
                <p><strong>ID:</strong> ${student.id}</p>
                <p><strong>Course:</strong> ${student.course}</p>
            `;
            studentsList.appendChild(studentCard);
        });

    } catch (err) {
        loading.style.display = 'none';
        error.style.display = 'block';
        error.innerHTML = `<strong>Error:</strong> ${err.message}. Make sure the backend server is running on port 5000.`;
        console.error('Error:', err);
    }
}

async function addStudent() {
    const name = prompt('Enter student name:');
    if (!name) return;

    const course = 'Full Stack Development';

    loading.style.display = 'block';
    error.style.display = 'none';

    try {
        const response = await fetch(`${BACKEND_URL}/api/students`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name, course })
        });

        if (!response.ok) {
            throw new Error('Failed to add student');
        }

        const newStudent = await response.json();
        loading.style.display = 'none';
        
        alert(`✓ Student "${newStudent.name}" added successfully!`);
        fetchStudents(); // Refresh list

    } catch (err) {
        loading.style.display = 'none';
        error.style.display = 'block';
        error.innerHTML = `<strong>Error:</strong> ${err.message}`;
        console.error('Error:', err);
    }
}

// Check backend connection on page load
window.addEventListener('load', () => {
    fetch(`${BACKEND_URL}/`)
        .then(res => res.json())
        .then(data => console.log('✓ Connected to backend:', data.message))
        .catch(err => console.warn('⚠ Backend not running yet. Start it with: npm start (in backend folder)'));
});
