const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Sample data (simulating MongoDB)
const students = [
  { id: 1, name: 'Alice', course: 'Full Stack Development' },
  { id: 2, name: 'Bob', course: 'Full Stack Development' },
  { id: 3, name: 'Charlie', course: 'Full Stack Development' }
];

// Routes
app.get('/', (req, res) => {
  res.json({ message: 'Welcome to Full Stack Lab Backend!' });
});

// Get all students
app.get('/api/students', (req, res) => {
  res.json(students);
});

// Get single student by ID
app.get('/api/students/:id', (req, res) => {
  const student = students.find(s => s.id === parseInt(req.params.id));
  if (!student) {
    return res.status(404).json({ message: 'Student not found' });
  }
  res.json(student);
});

// Create new student
app.post('/api/students', (req, res) => {
  const { name, course } = req.body;
  const newStudent = {
    id: students.length + 1,
    name,
    course
  };
  students.push(newStudent);
  res.status(201).json(newStudent);
});

// Start server
app.listen(PORT, () => {
  console.log(`✓ Backend server running at http://localhost:${PORT}`);
  console.log(`✓ API available at http://localhost:${PORT}/api/students`);
});
