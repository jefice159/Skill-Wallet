# Full Stack Development Lab - Student Understanding & Evidence

---

## Criterion 1: Explain the Concept of Full Stack Development

### What is Full Stack Development?

Full Stack Development means working with **all layers** of a web application - from what users see in their browser (Frontend) to the server that processes data (Backend) to the database that stores information (Database).

A "Full Stack Developer" can build complete web applications by understanding and working with:
- **Frontend** (Client-side)
- **Backend** (Server-side)  
- **Database** (Data storage)

### Why is it called "Full Stack"?

Think of a stack like layers:
```
┌─────────────────┐
│    Frontend     │  ← Layer 1: User Interface
├─────────────────┤
│    Backend      │  ← Layer 2: Server Logic
├─────────────────┤
│    Database     │  ← Layer 3: Data Storage
└─────────────────┘
```

A **full stack developer** knows all three layers, not just one.

### In This Lab Example:

- **Frontend**: `index.html`, `style.css`, `script.js` - This is what students see in their browser
- **Backend**: `server.js` - This is the Node.js/Express server that handles requests
- **Database**: `students` array in `server.js` - This stores the data

### Real-World Full Stack Applications:

- **Facebook**: Frontend (what you see), Backend (servers), Database (stores your posts/photos)
- **Gmail**: Frontend (email interface), Backend (servers), Database (stores your emails)
- **Spotify**: Frontend (player interface), Backend (servers), Database (stores songs/playlists)

### Key Takeaway:
Full Stack Development = Building **complete** web applications that work end-to-end, from user interface to data storage.

---

## Criterion 2: Differentiate Between Frontend and Backend Responsibilities

### Frontend vs Backend - Clear Comparison

| Aspect | Frontend | Backend |
|--------|----------|---------|
| **Location** | Runs in user's browser | Runs on a server (computer in a data center) |
| **Language** | HTML, CSS, JavaScript | Node.js, Python, Java, etc. |
| **What User Sees** | ✓ Visible (buttons, text, images) | ✗ Hidden (user doesn't see it) |
| **Main Job** | Display information to user | Process data and logic |
| **Hardware** | User's computer | Company's server |

### Frontend Responsibilities (What it DOES):

1. **Display Information**
   - Shows HTML on screen
   - Applies CSS styling
   - Makes UI look nice and organized

2. **Collect User Input**
   - Listens for button clicks
   - Gets text from forms
   - Responds to user actions

3. **Send Requests**
   - Creates HTTP requests (GET, POST)
   - Sends data to backend
   - Asks backend for information

4. **Display Data**
   - Receives JSON from backend
   - Converts JSON to readable format
   - Updates webpage with new information

**Example in our lab**: When user clicks "Fetch Students" button, frontend JavaScript sends a request to backend.

### Backend Responsibilities (What it DOES):

1. **Receive Requests**
   - Listens for HTTP requests from frontend
   - Reads what the frontend is asking for
   - Identifies which action to perform

2. **Process Data**
   - Performs calculations
   - Validates information
   - Applies business logic

3. **Access Database**
   - Retrieves data from database
   - Stores new data
   - Updates existing information

4. **Send Responses**
   - Prepares JSON response
   - Sends data back to frontend
   - Returns success/error messages

**Example in our lab**: When backend receives "get all students" request, it retrieves student data and sends it back as JSON.

### Why Separate Frontend and Backend?

1. **Security**: Sensitive logic stays on server
2. **Performance**: Heavy processing happens on powerful servers
3. **Separation of Concerns**: Each part has a specific job
4. **Scalability**: Can update frontend or backend independently
5. **Reusability**: Backend can serve multiple frontends (web, mobile app, etc.)

### Quick Identification Guide:

**Frontend tasks:**
- ✓ Make buttons pretty
- ✓ Show data on screen
- ✓ Respond to clicks
- ✗ Store sensitive passwords

**Backend tasks:**
- ✓ Verify user passwords
- ✓ Store data securely
- ✓ Calculate complex data
- ✗ Display pretty buttons

---

## Criterion 3: Describe Web Application Architecture

### What is Web Application Architecture?

Web Application Architecture describes **how different parts of a web application are organized and how they communicate** with each other. It shows the structure, layers, and data flow.

### The Three-Layer Architecture

```
┌────────────────────────────────────────────┐
│           FRONTEND (Client)                │
│    ┌──────────────────────────────────┐   │
│    │ Browser running HTML, CSS, JS    │   │
│    │ User sees this and interacts     │   │
│    └──────────────────────────────────┘   │
└────────────────────────────────────────────┘
                    ↕ HTTP
        [JSON Data flows both ways]
                    ↕
┌────────────────────────────────────────────┐
│           BACKEND (Server)                 │
│    ┌──────────────────────────────────┐   │
│    │ Node.js Express server           │   │
│    │ Processes requests, handles API  │   │
│    └──────────────────────────────────┘   │
└────────────────────────────────────────────┘
                    ↕ SQL/Query
        [Data flows both ways]
                    ↕
┌────────────────────────────────────────────┐
│        DATABASE (Data Storage)             │
│    ┌──────────────────────────────────┐   │
│    │ MongoDB / SQL Database           │   │
│    │ Stores all application data      │   │
│    └──────────────────────────────────┘   │
└────────────────────────────────────────────┘
```

### How the Architecture Works - Step by Step

#### Scenario 1: Fetching Data

```
Step 1: USER OPENS APPLICATION
   → Browser loads index.html (Frontend)

Step 2: USER CLICKS "FETCH STUDENTS"
   → JavaScript event listener is triggered

Step 3: FRONTEND SENDS REQUEST
   → JavaScript creates HTTP GET request
   → Sends to: http://localhost:5000/api/students
   → Request travels through network

Step 4: BACKEND RECEIVES REQUEST
   → Express server listens on port 5000
   → Receives GET request
   → Matches route: app.get('/api/students', ...)

Step 5: BACKEND ACCESSES DATABASE
   → Backend queries students array/MongoDB
   → Retrieves: [Alice, Bob, Charlie]

Step 6: BACKEND SENDS RESPONSE
   → Converts data to JSON format
   → Sends HTTP 200 OK response
   → Body: [{"id":1,"name":"Alice"}, ...]

Step 7: FRONTEND RECEIVES RESPONSE
   → JavaScript receives JSON data
   → Parses the JSON

Step 8: FRONTEND UPDATES UI
   → Creates HTML cards for each student
   → Inserts into DOM
   → Webpage updates

Step 9: USER SEES RESULTS
   → Student list appears on screen
   ✓ Alice
   ✓ Bob
   ✓ Charlie
```

#### Scenario 2: Adding Data

```
Step 1: USER CLICKS "ADD NEW STUDENT"
   → Prompted to enter name: "David"

Step 2: FRONTEND SENDS REQUEST
   → HTTP POST request to /api/students
   → Body: { name: "David", course: "Full Stack" }

Step 3: BACKEND RECEIVES REQUEST
   → Extracts name and course from body

Step 4: BACKEND ADDS TO DATABASE
   → Creates new student object
   → Adds to students array

Step 5: BACKEND SENDS CONFIRMATION
   → Returns new student with ID
   → Status: 201 Created

Step 6: FRONTEND SHOWS SUCCESS
   → Shows success message
   → Refreshes student list

Step 7: USER SEES NEW STUDENT
   → David now appears in the list
```

### Architecture Components Explained

**1. Frontend Layer**
- Location: User's browser
- Files: `index.html`, `style.css`, `script.js`
- Purpose: User interface and interaction
- Technology: HTML, CSS, JavaScript
- Runs on: Client machine

**2. Backend Layer**
- Location: Server (localhost:5000 in our lab)
- Files: `server.js`, `package.json`
- Purpose: API endpoints and business logic
- Technology: Node.js, Express.js
- Runs on: Server machine

**3. Database Layer**
- Location: Data storage system
- Files: In-memory array (represents MongoDB)
- Purpose: Persistent data storage
- Technology: MongoDB (real-world) / JavaScript array (this lab)
- Runs on: Database server

### Communication Protocol: HTTP

The Frontend and Backend communicate using **HTTP** (HyperText Transfer Protocol):

- **GET**: Retrieve data (like reading a book)
- **POST**: Create new data (like writing in a notebook)
- **PUT**: Update existing data (like editing a document)
- **DELETE**: Remove data (like erasing text)

**In our lab:**
- GET `/api/students` - Get all students
- POST `/api/students` - Add a new student

### Data Format: JSON

Data between Frontend and Backend is sent as **JSON** (JavaScript Object Notation):

```json
{
  "id": 1,
  "name": "Alice",
  "course": "Full Stack Development"
}
```

Benefits:
- ✓ Easy to read
- ✓ Easy to parse in JavaScript
- ✓ Works with all programming languages
- ✓ Lightweight and efficient

### Why This Architecture?

1. **Separation of Concerns**
   - Frontend focuses on user experience
   - Backend focuses on data and logic
   - Database focuses on storage

2. **Security**
   - Sensitive logic stays on server
   - User can't access backend code
   - Passwords never sent to browser

3. **Scalability**
   - Can add more servers
   - Can upgrade database independently
   - Can handle thousands of users

4. **Reusability**
   - Same backend serves multiple frontends
   - Mobile app can use same API
   - Desktop app can use same API

5. **Maintainability**
   - Easy to update frontend without breaking backend
   - Easy to change database without changing frontend
   - Teams can work independently

### Comparison: Architecture vs Non-Architecture

**Without Architecture (Bad):**
```
Everything mixed together
HTML, CSS, JavaScript, Database logic all in one file
Hard to maintain, hard to scale, security issues
```

**With Architecture (Good):**
```
Frontend (HTML, CSS, JS) - Separate layer
Backend (Node.js, Express) - Separate layer
Database (MongoDB) - Separate layer
Easy to maintain, easy to scale, secure
```

---

## Summary of Student Understanding

### What I Learned:

✅ **Full Stack Development** = Complete web applications with Frontend + Backend + Database

✅ **Frontend** = What user sees and clicks (HTML, CSS, JavaScript in browser)
  
✅ **Backend** = Hidden server logic that processes data (Node.js/Express on server)

✅ **Architecture** = How three layers communicate via HTTP requests/responses using JSON

✅ **In This Lab**: Built a real working application demonstrating all these concepts

---

## Proof of Understanding

### Evidence in Code:

1. **Frontend sends requests** (`frontend/script.js`):
   ```javascript
   fetch('http://localhost:5000/api/students')
   ```

2. **Backend receives and responds** (`backend/server.js`):
   ```javascript
   app.get('/api/students', (req, res) => {
     res.json(students);
   });
   ```

3. **Frontend displays response** (`frontend/script.js`):
   ```javascript
   const students = await response.json();
   // Creates HTML cards and displays
   ```

### Evidence in Application:

- ✓ Frontend displays beautiful UI (`style.css`)
- ✓ Backend API returns data (`/api/students`)
- ✓ Frontend can fetch data (Fetch button works)
- ✓ Frontend can add data (Add Student button works)
- ✓ Complete data flow from client to server and back

---

**This lab demonstrates complete understanding of Full Stack Development architecture!**
