# MERN Stack Architecture Guide

## Overview
This guide helps you understand the Full Stack Development architecture and how all components work together.

---

## 1. The Three Layers Explained

### 🎨 Frontend Layer (Client)
**Location**: Browser on student's computer
**Technology**: HTML, CSS, JavaScript
**Responsibilities**:
- Display user interface
- Collect user input
- Send requests to backend
- Display data received from backend

**In This Lab**:
- `index.html` - Visual structure
- `style.css` - Beautiful design
- `script.js` - Interaction logic

**Example**: When user clicks "Fetch Students", frontend JavaScript code runs and sends a request to the backend.

---

### ⚙️ Backend Layer (Server)
**Location**: Node.js server running on localhost:5000
**Technology**: Node.js, Express.js
**Responsibilities**:
- Receive requests from frontend
- Process business logic
- Access database
- Send responses back to frontend

**In This Lab**:
- `server.js` - Express server with API endpoints
- Runs continuously listening for requests
- Returns JSON data to frontend

**Example**: When backend receives a request for students, it retrieves data and sends it back as JSON.

---

### 💾 Database Layer (Data Storage)
**Location**: Data storage system
**Technology**: MongoDB (in full MERN) / Simple array (in this lab)
**Responsibilities**:
- Store persistent data
- Retrieve data when requested
- Update records
- Delete records

**In This Lab**:
- `students` array in server.js
- Simulates MongoDB functionality
- Holds student records

**Example**: Stores information like Alice, Bob, Charlie and any newly added students.

---

## 2. How Data Flows: Complete Request Cycle

### Scenario: Student Clicks "Fetch Students" Button

```
┌─────────────────────────────────────────────────────────────┐
│                     FRONTEND (Browser)                       │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ 1. User clicks "Fetch Students" button              │  │
│  │    (Event listener triggers in script.js)            │  │
│  └──────────────────────────────────────────────────────┘  │
│                           │                                 │
│                           ▼                                 │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ 2. JavaScript creates HTTP GET request              │  │
│  │    URL: http://localhost:5000/api/students          │  │
│  │    fetch() sends request                             │  │
│  └──────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
                           │
            ═══════════════╩═══════════════
            Network/Internet (HTTP Request)
            ═══════════════╦═══════════════
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                   BACKEND (Server)                          │
│             Running on localhost:5000                       │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ 3. Express server receives GET request              │  │
│  │    Request path: /api/students                       │  │
│  │    Matches route handler in server.js               │  │
│  └──────────────────────────────────────────────────────┘  │
│                           │                                 │
│                           ▼                                 │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ 4. Backend accesses data (students array)           │  │
│  │    Prepares response                                │  │
│  │    Converts to JSON format                          │  │
│  └──────────────────────────────────────────────────────┘  │
│                           │                                 │
│                           ▼                                 │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ 5. Sends HTTP response with JSON data              │  │
│  │    Status: 200 OK                                   │  │
│  │    Body: [{"id":1,"name":"Alice",...}, ...]        │  │
│  └──────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
                           │
            ═══════════════╩═══════════════
            Network/Internet (HTTP Response)
            ═══════════════╦═══════════════
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                     FRONTEND (Browser)                       │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ 6. JavaScript receives response                      │  │
│  │    Parses JSON data                                  │  │
│  └──────────────────────────────────────────────────────┘  │
│                           │                                 │
│                           ▼                                 │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ 7. Updates HTML dynamically                         │  │
│  │    Creates cards for each student                    │  │
│  │    Inserts into DOM                                  │  │
│  └──────────────────────────────────────────────────────┘  │
│                           │                                 │
│                           ▼                                 │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ 8. User sees updated UI with student list           │  │
│  │    - Alice                                           │  │
│  │    - Bob                                             │  │
│  │    - Charlie                                         │  │
│  └──────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

---

## 3. Code Examples

### Frontend Code (script.js) - Sending Request
```javascript
// Step 1: User clicks button, this function runs
async function fetchStudents() {
    try {
        // Step 2: Send GET request to backend
        const response = await fetch('http://localhost:5000/api/students');
        
        // Step 3: Receive response
        const students = await response.json();
        
        // Step 4: Update UI with received data
        students.forEach(student => {
            // Create HTML card
            const card = document.createElement('div');
            card.innerHTML = `<h4>${student.name}</h4>`;
            document.getElementById('studentsList').appendChild(card);
        });
    } catch (err) {
        console.error('Error:', err);
    }
}
```

### Backend Code (server.js) - Handling Request
```javascript
// When frontend sends GET request to /api/students
app.get('/api/students', (req, res) => {
    // Backend has this data
    const students = [
        { id: 1, name: 'Alice', course: 'Full Stack Development' },
        { id: 2, name: 'Bob', course: 'Full Stack Development' }
    ];
    
    // Send the data back as JSON response
    res.json(students);
});
```

---

## 4. Key Terminology

| Term | Meaning | Example |
|------|---------|---------|
| **HTTP** | Protocol for communication | GET, POST, PUT, DELETE requests |
| **Request** | Message FROM frontend TO backend | "Please give me all students" |
| **Response** | Message FROM backend TO frontend | JSON data with student list |
| **Endpoint** | Address on backend that handles requests | `/api/students` |
| **JSON** | Format for data exchange | `{"name": "Alice", "id": 1}` |
| **REST API** | Rules for building web services | Standard HTTP methods for data operations |
| **Port** | Gateway for network communication | 5000 (backend listens here) |
| **localhost** | Your computer's address | 127.0.0.1 (same machine) |
| **CORS** | Permission to access from different origins | Enables frontend (port 3000) to talk to backend (port 5000) |

---

## 5. Real World Analogy

Think of it like a restaurant:

- **Frontend** = Customer sitting at table
- **Backend** = Kitchen and waiter
- **Database** = Recipe book and pantry

**Process**:
1. Customer (Frontend) places order
2. Waiter (HTTP Request) takes order to kitchen
3. Chef (Backend) reads order and prepares food
4. Waiter (HTTP Response) brings food back
5. Customer (Frontend) eats and is happy!

---

## 6. What Students Learn

By completing this lab, students understand:

✅ Frontend and Backend are separate systems
✅ They communicate via HTTP requests/responses
✅ Frontend runs in browser, Backend runs on server
✅ Data is sent as JSON format
✅ Frontend displays data received from backend
✅ Backend processes data and returns responses
✅ Database stores persistent information
✅ How to build a complete web application

---

## 7. Testing the Lab

### How to Verify Understanding:

**Question 1**: "What happens when you click 'Fetch Students'?"
- ✅ Should explain: Browser sends GET request to backend → Backend retrieves data → Sends back JSON → Frontend displays it

**Question 2**: "Where does the data come from?"
- ✅ Should explain: Data is stored in the backend (currently in array, but could be MongoDB)

**Question 3**: "What is localhost:5000?"
- ✅ Should explain: The address where the backend server is running on your computer

**Question 4**: "Why do we need a backend?"
- ✅ Should explain: To process data, store information, and provide it securely to frontend

---

**Ready to test? Open the application and click the buttons!**
