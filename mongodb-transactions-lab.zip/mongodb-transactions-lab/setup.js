-- MongoDB Transactions Lab Setup
-- Run these commands in mongosh to set up the replica set and sample data

-- 1. Initiate replica set (run in mongosh)
rs.initiate()

-- 2. Check replica set status
rs.status()

-- 3. Switch to bankDB and create sample data
use bankDB

db.accounts.insertMany([
    { _id: 1, name: "Alice", balance: 100 },
    { _id: 2, name: "Bob", balance: 50 }
])

-- 4. Verify data
db.accounts.find()