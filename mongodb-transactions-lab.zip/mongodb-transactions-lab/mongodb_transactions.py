#!/usr/bin/env python3
"""
MongoDB Transactions Lab - Aldrin Magalang
This script demonstrates MongoDB transactions for fund transfers between accounts.
"""

from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, OperationFailure

def connect_to_mongodb():
    """Step 1: Connect to MongoDB"""
    uri = "mongodb://localhost:27017/"
    client = MongoClient(uri)

    try:
        client.admin.command('ping')
        print("Pinged your deployment. You have successfully connected to MongoDB!")
    except ConnectionFailure as e:
        print(f"Connection failed: {e}")
        return None

    db = client["bankDB"]
    accounts = db["accounts"]
    return client, db, accounts

def start_transaction_example(client, accounts):
    """Step 2: Start a Transaction"""
    print("\n--- Step 2: Start a Transaction ---")
    with client.start_session() as session:
        session.start_transaction()
        try:
            print("Transaction started.")
            # Commit the transaction
            session.commit_transaction()
            print("Transaction committed.")
        except Exception as e:
            session.abort_transaction()
            print("Transaction aborted.")
            print(e)

def fund_transfer_success(client, accounts):
    """Step 3: Implement the Fund Transfer"""
    print("\n--- Step 3: Fund Transfer (Success) ---")
    with client.start_session() as session:
        session.start_transaction()
        try:
            # Debit Alice's account
            accounts.update_one(
                { "_id": 1 },
                { "$inc": { "balance": -30 } },
                session=session
            )

            # Credit Bob's account
            accounts.update_one(
                { "_id": 2 },
                { "$inc": { "balance": 30 } },
                session=session
            )

            # Commit the transaction
            session.commit_transaction()
            print("Transaction committed. Funds transferred successfully.")
        except Exception as e:
            session.abort_transaction()
            print("Transaction aborted. Funds transfer failed.")
            print(e)

def fund_transfer_failure(client, accounts):
    """Step 4: Simulate a Failure and Rollback"""
    print("\n--- Step 4: Fund Transfer (Failure Simulation) ---")
    with client.start_session() as session:
        session.start_transaction()
        try:
            # Debit Alice's account
            accounts.update_one(
                { "_id": 1 },
                { "$inc": { "balance": -30 } },
                session=session
            )

            # Simulate an error
            raise ValueError("Simulated error during transaction")

            # Credit Bob's account (this will not be executed)
            accounts.update_one(
                { "_id": 2 },
                { "$inc": { "balance": 30 } },
                session=session
            )

            # Commit the transaction
            session.commit_transaction()
            print("Transaction committed. Funds transferred successfully.")
        except Exception as e:
            session.abort_transaction()
            print("Transaction aborted. Funds transfer failed.")
            print(e)

def verify_data_consistency(accounts):
    """Step 5: Verify Data Consistency"""
    print("\n--- Step 5: Verify Data Consistency ---")
    alice = accounts.find_one({"_id": 1})
    bob = accounts.find_one({"_id": 2})

    print(f"Alice's balance: {alice['balance']}")
    print(f"Bob's balance: {bob['balance']}")

def setup_sample_data(accounts):
    """Setup sample data if not exists"""
    print("\n--- Setting up sample data ---")
    if accounts.count_documents({}) == 0:
        accounts.insert_many([
            { "_id": 1, "name": "Alice", "balance": 100 },
            { "_id": 2, "name": "Bob", "balance": 50 }
        ])
        print("Sample data inserted.")
    else:
        print("Sample data already exists.")

def main():
    """Main function to run all steps"""
    print("MongoDB Transactions Lab - Aldrin Magalang")

    # Connect to MongoDB
    result = connect_to_mongodb()
    if not result:
        return

    client, db, accounts = result

    # Setup sample data
    setup_sample_data(accounts)

    # Show initial state
    print("\n--- Initial State ---")
    verify_data_consistency(accounts)

    # Step 2: Start transaction example
    start_transaction_example(client, accounts)

    # Step 3: Successful fund transfer
    fund_transfer_success(client, accounts)
    verify_data_consistency(accounts)

    # Step 4: Failed fund transfer (rollback)
    fund_transfer_failure(client, accounts)
    verify_data_consistency(accounts)

    print("\n--- Lab completed ---")

if __name__ == "__main__":
    main()