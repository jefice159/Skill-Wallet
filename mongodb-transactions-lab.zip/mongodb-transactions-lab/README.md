# MongoDB Transactions Lab

This lab demonstrates implementing transactions in MongoDB for atomic operations, focusing on fund transfers between bank accounts.

## Overview

The project includes:
- `mongodb_transactions.py`: Complete Python script implementing all transaction steps
- `setup.js`: MongoDB shell commands for replica set configuration and sample data
- `mongodb_transactions_report.txt`: Analysis report with outputs and challenges overcome

## Setup Instructions

### 1. Install MongoDB
Download and install MongoDB 4.0+ from https://www.mongodb.com/try/download/community

### 2. Configure Replica Set
```bash
# Create data directory
mkdir /data/db

# Start MongoDB with replica set
mongod --replSet rs0 --dbpath /data/db --bind_ip localhost --port 27017
```

### 3. Initialize Replica Set
Open another terminal and run:
```bash
mongosh
rs.initiate()
rs.status()
```

### 4. Install Python Dependencies
```bash
pip install pymongo
```

### 5. Setup Sample Data
In mongosh:
```javascript
use bankDB
db.accounts.insertMany([
    { _id: 1, name: "Alice", balance: 100 },
    { _id: 2, name: "Bob", balance: 50 }
])
db.accounts.find()
```

## Running the Lab

Execute the Python script:
```bash
python mongodb_transactions.py
```

The script will:
1. Connect to MongoDB
2. Setup sample data if needed
3. Demonstrate transaction start/commit
4. Perform successful fund transfer
5. Simulate failure and rollback
6. Verify data consistency throughout

## Expected Results

- Successful connection to MongoDB
- Initial balances: Alice=100, Bob=50
- After transfer: Alice=70, Bob=80
- After rollback: Balances unchanged from post-transfer state
- Clear demonstration of atomicity and rollback functionality

## Key Concepts Demonstrated

- Replica set requirement for transactions
- Session management with PyMongo
- Atomic operations across multiple documents
- Error handling and rollback
- Data consistency verification

## Troubleshooting

- **Transaction errors**: Ensure replica set is initialized (`rs.status()` shows PRIMARY)
- **Connection issues**: Verify MongoDB is running on localhost:27017
- **Import errors**: Install PyMongo with `pip install pymongo`
- **Permission errors**: Run mongod with appropriate permissions for data directory