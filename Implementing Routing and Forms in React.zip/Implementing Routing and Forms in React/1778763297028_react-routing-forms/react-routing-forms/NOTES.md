# React Routing and Forms Lab Notes

## Routing with React Router

- `App.js` uses `BrowserRouter` to enable client-side navigation.
- `Link` components provide navigation links without full page reloads.
- `Routes` and `Route` map paths to page components.
- This creates a multi-page experience while staying in a single React application.

## Controlled Form Implementation

- `Form.js` uses `useState` to manage the values of `name`, `email`, and `message`.
- Input values are controlled by React state through the `value` prop.
- `onChange` updates the state as the user types, keeping the UI in sync with state.

## Validation and Submission

- The `validate` function checks each field and builds an `errors` object.
- Validation rules include required fields and email format checking using a regex.
- If validation passes, the form submission logs the data and clears the inputs.
- If validation fails, error messages appear below the relevant fields.

## Component Organization

- Each page is separated into a dedicated component under `src/components`.
- This improves readability and makes each page easy to maintain.
- `App.css` contains shared styling and navigation layout.

## Why this structure is useful

- Routing and page composition are separated from page content.
- Controlled forms keep input state predictable and easy to validate.
- Modular components support scalability as the application grows.
