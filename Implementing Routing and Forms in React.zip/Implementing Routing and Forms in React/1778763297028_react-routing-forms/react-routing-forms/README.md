# React Routing and Forms Lab

This lab demonstrates client-side routing with React Router and controlled form handling in React.

## Overview

The lab shows how to:

- Implement navigation using `react-router-dom`.
- Build reusable page components for Home, About, Contact, and a Form page.
- Create a controlled form with `useState`.
- Validate form input and display feedback.
- Organize React components in a modular structure.

## Project Structure

- `package.json`
- `public/index.html`
- `src/index.js`
- `src/App.js`
- `src/App.css`
- `src/components/Home.js`
- `src/components/About.js`
- `src/components/Contact.js`
- `src/components/Form.js`
- `README.md`

## Setup and Run

From the `react-routing-forms` directory:

```bash
npm install
npm start
```

Then open `http://localhost:3000`.

## Expected Behavior

- Navigation links should switch between Home, About, Contact, and Form pages.
- The form should update React state when typing into inputs.
- Form validation should display error messages for empty or invalid fields.
- Successful submission should log the form data to the console and clear the form.

## Notes

This lab demonstrates both routing and form handling patterns in a simple React application. The code is organized into reusable components and includes basic styling for navigation.
