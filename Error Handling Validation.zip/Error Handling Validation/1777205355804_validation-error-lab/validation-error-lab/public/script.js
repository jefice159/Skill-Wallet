document.getElementById('form').addEventListener('submit', async (e) => {
  e.preventDefault();

  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const age = document.getElementById('age').value;

  // Client-side validation
  let clientErrors = [];

  if (!email.includes('@')) {
    clientErrors.push('Email must contain @');
  }

  if (password.length < 8) {
    clientErrors.push('Password must be at least 8 characters long');
  }

  if (isNaN(age) || age === '') {
    clientErrors.push('Age must be a number');
  }

  if (clientErrors.length > 0) {
    document.getElementById('message').innerHTML = '<p style="color:red;">' + clientErrors.join('<br>') + '</p>';
    return;
  }

  // Send to server
  try {
    const response = await fetch('/submit', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email, password, age })
    });

    const data = await response.json();

    if (response.ok) {
      document.getElementById('message').innerHTML = '<p style="color:green;">' + data.message + '</p>';
    } else {
      document.getElementById('message').innerHTML = '<p style="color:red;">' + data.errors.join('<br>') + '</p>';
    }
  } catch (error) {
    document.getElementById('message').innerHTML = '<p style="color:red;">Network error</p>';
  }
});