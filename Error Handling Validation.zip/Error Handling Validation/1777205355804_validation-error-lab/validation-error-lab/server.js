const express = require('express');
const app = express();
const port = 3000;

// Middleware to parse JSON
app.use(express.json());
app.use(express.static('public'));

// Route for form submission
app.post('/submit', (req, res) => {
  const { email, password, age } = req.body;

  // Validation
  let errors = [];

  if (!email || !email.includes('@')) {
    errors.push('Email must contain @');
  }

  if (!password || password.length < 8) {
    errors.push('Password must be at least 8 characters long');
  }

  if (!age || isNaN(age)) {
    errors.push('Age must be a number');
  }

  if (errors.length > 0) {
    return res.status(400).json({ errors });
  }

  // Success
  res.status(200).json({ message: 'Form submitted successfully!' });
});

// Simulate a server error
app.get('/error', (req, res) => {
  res.status(500).json({ error: 'Internal server error' });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});