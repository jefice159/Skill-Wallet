-- SQL Index Performance Lab Setup
-- This script creates the database, table, and populates it with 100,000 rows

-- Create database
CREATE DATABASE IF NOT EXISTS index_performance_lab;
USE index_performance_lab;

-- Create table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Stored procedure to insert users
DELIMITER //

CREATE PROCEDURE IF NOT EXISTS insert_users(IN num_rows INT)
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= num_rows DO
        INSERT INTO users (username, email)
        VALUES (CONCAT('user', i), CONCAT('user', i, '@example.com'));
        SET i = i + 1;
    END WHILE;
END //

DELIMITER ;

-- Call the procedure to insert 100,000 rows
CALL insert_users(100000);

-- Verify insertion
SELECT COUNT(*) FROM users;