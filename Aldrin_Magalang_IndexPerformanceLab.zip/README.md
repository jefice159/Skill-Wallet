# SQL Index Performance Lab

This lab demonstrates the performance impact of database indexes in MySQL. You'll create a large dataset, run queries with and without indexes, and analyze the execution plans to understand optimization.

## Overview

The project includes:

- `setup.sql`: Database creation, table setup, and data population with 100,000 rows.
- `Aldrin_Magalang_IndexPerformanceLab.txt`: Complete lab submission with all steps, code, outputs, and analysis.

## Setup

1. Install MySQL Community Server and MySQL Workbench.
2. Open MySQL Workbench and connect to your MySQL server.
3. Run the `setup.sql` script to create the database and populate data.

## Running the Lab

Execute the SQL commands in `Aldrin_Magalang_IndexPerformanceLab.txt` step by step. Use MySQL Workbench to run queries and view execution times in the "Action Output" tab.

## What this lab covers

- Creating large datasets for performance testing.
- Measuring query execution times with and without indexes.
- Using EXPLAIN to analyze query execution plans.
- Creating single-column indexes for optimization.
- Understanding index limitations and trade-offs.
- Experimenting with different query patterns.

## Expected Results

- 99%+ performance improvement after indexing.
- EXPLAIN shows transition from ALL (table scan) to ref (index lookup).
- Clear understanding of when indexes help and when they don't.

## Notes

Enable query profiling in MySQL Workbench to see execution times. Run ANALYZE TABLE users; if performance doesn't improve after indexing. Compare execution plans before and after index creation.