# Mongoose Schemas Lab

This lab demonstrates how to define Mongoose schemas for MongoDB, including validation, default values, schema options, and embedded documents.

## Overview

The project includes:

- `db.js`: Connects to MongoDB using Mongoose.
- `index.js`: Defines Mongoose schemas and creates a sample `Product` document.
- `package.json`: Includes the `mongoose` dependency and a start script.

## Setup

From the `mongoose-schemas-lab` directory, run:

```bash
npm install
npm start
```

Ensure MongoDB is running locally at `mongodb://127.0.0.1:27017/mongoose_lab`.

## What this demonstrates

- Defining Mongoose schemas with field types.
- Adding validation rules (`required`, `min`).
- Applying default values for schema fields.
- Using `timestamps` to auto-add `createdAt` and `updatedAt`.
- Embedding a subdocument schema (`dimensionSchema`) inside the main schema.

## Notes

The `index.js` file creates a `Product` instance and saves it to the database. If validation fails, the errors are logged.
