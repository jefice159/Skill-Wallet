# Mongoose Schemas Lab Notes

## db.js

- Connects to MongoDB using Mongoose.
- Uses `useNewUrlParser` and `useUnifiedTopology` for modern connection behavior.
- Exits the process on connection failure.

## index.js

- Imports the database connection and connects when run.
- Defines `dimensionSchema` as an embedded subdocument schema.
- Defines `productSchema` with validation, defaults, and timestamps.
- Creates the `Product` model from the schema.
- Saves a sample product to MongoDB and logs the result.
- Closes the database connection after the save completes.

## Schema Features

- `required: true` enforces the presence of the `name` and `price` fields.
- `min: 0` prevents negative prices.
- `default: 'General'` provides a fallback category.
- `timestamps: true` automatically adds `createdAt` and `updatedAt`.
- `dimensions` embeds a nested schema, illustrating subdocuments.

## What to test

- Create a valid product and confirm it saves successfully.
- Remove `name` or set `price` negative to trigger validation errors.
- Inspect the saved document in MongoDB to confirm defaults and timestamps.
