// setup.js - Database setup and data insertion for MongoDB Indexes Lab

// Connect to MongoDB and create database
use mydatabase

// Create collection
db.createCollection("products")

// Insert sample data
db.products.insertMany([
  { name: "Laptop", category: "Electronics", price: 1200, tags: ["new", "featured"] },
  { name: "Smartphone", category: "Electronics", price: 800, tags: ["popular", "sale"] },
  { name: "T-shirt", category: "Clothing", price: 25, tags: ["new", "discount"] },
  { name: "Jeans", category: "Clothing", price: 75, tags: ["popular"] },
  { name: "Coffee Maker", category: "Appliances", price: 100, tags: ["new"] },
  { name: "Blender", category: "Appliances", price: 50, tags: ["sale"] },
  { name: "Tablet", category: "Electronics", price: 300, tags: ["featured"] },
  { name: "Dress", category: "Clothing", price: 60, tags: ["discount"] },
  { name: "Microwave", category: "Appliances", price: 150, tags: ["popular"] },
  { name: "Headphones", category: "Electronics", price: 120, tags: ["new", "sale"] }
]);

// Verify data insertion
db.products.find().toArray();
