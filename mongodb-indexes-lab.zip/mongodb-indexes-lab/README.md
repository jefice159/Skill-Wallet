# MongoDB Indexes Lab

This lab demonstrates creating and managing indexes in MongoDB to optimize query performance, including single-field, compound, and multi-key indexes.

## Overview

The project includes:

- `setup.js`: Database creation, collection setup, and sample data insertion.
- `Aldrin_Magalang_MongoDBIndexes.txt`: Complete lab submission with code, outputs, and explanations.

## Setup

1. Ensure MongoDB is installed and running (`mongod`).
2. Open MongoDB shell (`mongosh`).
3. Load and run the setup script:

```javascript
load('setup.js')
```

This creates the `mydatabase` database, `products` collection, and inserts sample data.

## Running the Lab

Execute the commands in `Aldrin_Magalang_MongoDBIndexes.txt` step by step in the MongoDB shell. Use `explain("executionStats")` to analyze performance before and after creating indexes.

## What this lab covers

- Analyzing query performance without indexes.
- Creating single-field indexes for improved lookup speed.
- Building compound indexes for multi-field queries.
- Implementing multi-key indexes for array fields.
- Dropping indexes and understanding their impact.

## Expected Results

- Significant performance improvements after each index creation.
- Reduced execution time and documents examined.
- Index usage confirmed by IXSCAN in explain() output.

## Notes

Run `db.products.getIndexes()` to verify index creation. Compare execution stats before and after indexing to quantify improvements.
