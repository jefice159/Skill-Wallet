-- ComplexAggregations_Aldrin_Magalang.sql
-- Lab: Complex Aggregations using SQL

-- Step 1: Calculate Basic Aggregations
-- Description: Calculate the total quantity, average unit price, and total revenue for all sales.
SELECT
    SUM(quantity) AS total_quantity,
    AVG(unit_price) AS average_unit_price,
    SUM(quantity * unit_price) AS total_revenue
FROM sales;

-- Step 2: Group Sales by Region
-- Description: Calculate the total revenue for each region.
SELECT
    region,
    SUM(quantity * unit_price) AS total_revenue
FROM sales
GROUP BY region;

-- Step 3: Group Sales by Region and Product
-- Description: Calculate the total revenue for each region and product combination.
SELECT
    region,
    product_id,
    SUM(quantity * unit_price) AS total_revenue
FROM sales
GROUP BY region, product_id
ORDER BY region, product_id;

-- Step 4: Calculate Running Total of Revenue by Region
-- Description: Calculate the running total of revenue for each region over the sale dates using window functions.
SELECT
    sale_date,
    region,
    SUM(quantity * unit_price) AS daily_revenue,
    SUM(SUM(quantity * unit_price)) OVER (PARTITION BY region ORDER BY sale_date) AS running_total_revenue
FROM sales
GROUP BY sale_date, region
ORDER BY region, sale_date;

-- Step 5: Calculate Moving Average of Revenue
-- Description: Calculate the 3-day moving average of revenue for each region using window functions.
SELECT
    sale_date,
    region,
    SUM(quantity * unit_price) AS daily_revenue,
    AVG(SUM(quantity * unit_price)) OVER (PARTITION BY region ORDER BY sale_date ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) AS moving_average_revenue
FROM sales
GROUP BY sale_date, region
ORDER BY region, sale_date;
