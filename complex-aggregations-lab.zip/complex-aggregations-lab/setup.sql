-- setup.sql - Database setup and data insertion for Complex Aggregations Lab

-- Create database (if not exists)
CREATE DATABASE IF NOT EXISTS sales_data;

-- Use the database
USE sales_data;

-- Create sales table
CREATE TABLE IF NOT EXISTS sales (
    sale_id INT PRIMARY KEY,
    product_id INT,
    sale_date DATE,
    quantity INT,
    unit_price DECIMAL(10, 2),
    region VARCHAR(50)
);

-- Insert sample data
INSERT INTO sales (sale_id, product_id, sale_date, quantity, unit_price, region) VALUES
(1, 101, '2023-01-01', 10, 25.00, 'North'),
(2, 102, '2023-01-01', 5, 50.00, 'South'),
(3, 101, '2023-01-02', 15, 25.00, 'North'),
(4, 103, '2023-01-02', 8, 75.00, 'East'),
(5, 102, '2023-01-03', 12, 50.00, 'South'),
(6, 101, '2023-01-03', 20, 25.00, 'North'),
(7, 104, '2023-01-04', 3, 100.00, 'West'),
(8, 103, '2023-01-04', 6, 75.00, 'East'),
(9, 102, '2023-01-05', 10, 50.00, 'South'),
(10, 101, '2023-01-05', 25, 25.00, 'North'),
(11, 104, '2023-01-06', 5, 100.00, 'West'),
(12, 103, '2023-01-06', 7, 75.00, 'East'),
(13, 102, '2023-01-07', 15, 50.00, 'South'),
(14, 101, '2023-01-07', 30, 25.00, 'North'),
(15, 104, '2023-01-08', 4, 100.00, 'West');

-- Verify data insertion
SELECT * FROM sales;
