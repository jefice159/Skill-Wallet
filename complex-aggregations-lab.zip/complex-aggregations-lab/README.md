# Complex Aggregations Lab

This lab demonstrates advanced SQL aggregation techniques, including multiple aggregation functions, grouping by multiple columns, and window functions for running totals and moving averages.

## Overview

The project includes:

- `setup.sql`: Database creation, table setup, and sample data insertion.
- `ComplexAggregations_Aldrin_Magalang.sql`: All SQL queries for the lab steps with comments.

## Setup

1. Install a SQL database system (MySQL, PostgreSQL, or SQLite).
2. Install a SQL client (MySQL Workbench, pgAdmin, or DBeaver).
3. Run `setup.sql` to create the database and insert sample data.
4. Execute the queries in `ComplexAggregations_Aldrin_Magalang.sql` step by step.

## What this lab covers

- Basic aggregations with SUM, AVG.
- Grouping data with GROUP BY.
- Window functions for running totals and moving averages.
- Multi-dimensional grouping and ordering.

## Expected Output

- Step 1: Overall totals and averages.
- Step 2: Revenue per region.
- Step 3: Revenue per region and product.
- Step 4: Running totals by region over time.
- Step 5: 3-day moving averages by region.

## Notes

Ensure your database supports window functions (MySQL 8+, PostgreSQL, etc.). If using SQLite, some window functions may not be available. Test queries in your SQL client and compare with expected results.
