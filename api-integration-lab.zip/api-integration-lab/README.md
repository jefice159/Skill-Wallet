# API Integration Lab

This React lab demonstrates how to fetch data from an external API and display it in a user interface.

## Overview

The lab includes:

- `App.js`: Fetches user data from `https://jsonplaceholder.typicode.com/users` using `fetch`, tracks loading and error states, and renders the list of users.
- `User.js`: A presentational component that receives a user object as a prop and displays the user's information.
- `App.css`: Styles the page and user cards.

## Setup and Run

From the `api-integration-lab` directory:

```bash
npm install
npm start
```

Then open `http://localhost:3000` in your browser.

## Expected Behavior

- The app shows a `Loading users...` message while fetching data.
- Once loaded, it displays a list of users fetched from the API.
- If an error occurs, an error message is displayed.

## Notes

This lab demonstrates asynchronous data fetching with `useEffect`, state management with `useState`, and rendering dynamic data in React.
