# API Integration Lab Notes

## API Fetching

- `App.js` uses `useEffect` to perform the API fetch when the component mounts.
- The empty dependency array `[]` ensures the fetch runs only once.
- `fetch` is used to call the JSON placeholder API.
- The response is checked with `response.ok`, and an error is thrown when the request fails.

## State Management

- `users` stores the fetched user list.
- `loading` tracks whether the fetch is still in progress.
- `error` stores any fetch-related error.
- The component renders different UI states for loading, error, and success.

## Component Design

- `User.js` is a reusable component that renders user details from props.
- Separating the `User` component keeps `App.js` focused on data fetching and state handling.

## Styling

- `App.css` adds a simple card layout for user items.
- The design improves readability and visual structure.

## Validation

- The app handles asynchronous operations and error states.
- It demonstrates how to integrate external API data into a React UI.
